<?php


// ** MySQL settings ** //
/** The name of the database for WordPress */
define('DB_NAME', 'worldtec170252060218');

/** MySQL database username */
define('DB_USER', '561_media');

/** MySQL database password */
define('DB_PASSWORD', '561_media');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('AUTH_KEY',         'DB.Z|*>rPbO|pbHal8qj=4Xr`sZQRpw~H9vb%F$yBFjHQ<6qk#(R71 {5Ar,2isp');
define('SECURE_AUTH_KEY',  ':()x?(+O{D-3?|-kcxMwg!=8o$S&5tfUy%fn{%j;U+Bkp}1>YwRKQse/}/y<Vw-d');
define('LOGGED_IN_KEY',    '~bo85*0*GT66JnoLh$?-]}Z@OO851X.eybr^Hhjv]GV.v]$yN*SzE.1=}L+569BG');
define('NONCE_KEY',        '6(j?(D|{Arbj>?4A2@}]mFF%Ilc``2 7rCpF>8j +RfZ&g~QH]?9UUhZc>[=hdd#');
define('AUTH_SALT',        '`]8Da*LM>&kz6-#f3-b#./3nFh%/zpi]0m3xf{.*~O+KE=y]lB$s*~j|CK-2=!WM');
define('SECURE_AUTH_SALT', '#C`f&-)#9rl_PsrE}X:!j)bHqgu<KPNGo7(7Q]ulyaNFJPvC}P6U/gS/b,MRlP/&');
define('LOGGED_IN_SALT',   'x<s@(>be9[%4|cTTsXiFa0Y+R+hG1{d-oc0[Sndf.ji&6U0yy$OoibF3:cfo}e1U');
define('NONCE_SALT',       '6?Fc`+][Uw(<B0|!}+^}ggrq|0MiU2q-k]&?G;lI6EeTYT&pgbs;6MhpI5NOU#Qo');


$table_prefix = 'wp_';





define('ALLOW_UNFILTERED_UPLOADS', true);
define('WP_MEMORY_LIMIT','64M');
define('WP_DEBUG', false);
/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
define('FS_METHOD','direct');
